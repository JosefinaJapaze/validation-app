import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '../App'
import UserList from './UserList'
import DocumentViewer from './DocumentViewer'
import './Dashboard.css'

function Dashboard() {
  const { user, logout } = useAuth()
  const [users, setUsers] = useState([])
  const [selectedUser, setSelectedUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchPendingUsers = async () => {
    setLoading(true)
    setError('')
    
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/users/pending', {
        headers: { 'Authorization': `Bearer ${token}` }
      })

      if (!response.ok) {
        throw new Error('Error al cargar usuarios')
      }

      const data = await response.json()
      setUsers(data.users)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPendingUsers()
  }, [])

  const handleSelectUser = (user) => {
    setSelectedUser(user)
  }

  const handleValidate = async (userId) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/users/${userId}/validate`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      })

      if (!response.ok) throw new Error('Error al validar')

      // Remover usuario de la lista y cerrar el visor
      setUsers(prev => prev.filter(u => u.userId !== userId))
      setSelectedUser(null)
    } catch (err) {
      alert('Error al validar usuario: ' + err.message)
    }
  }

  const handleReject = async (userId, reason) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/users/${userId}/reject`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ reason })
      })

      if (!response.ok) throw new Error('Error al rechazar')

      setUsers(prev => prev.filter(u => u.userId !== userId))
      setSelectedUser(null)
    } catch (err) {
      alert('Error al rechazar usuario: ' + err.message)
    }
  }

  return (
    <div className="dashboard">
      {/* Header */}
      <header className="dashboard-header">
        <div className="header-left">
          <div className="header-logo">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <path d="M9 12l2 2 4-4"/>
            </svg>
          </div>
          <div>
            <h1>Panel de Validación</h1>
            <p>Usuarios pendientes de revisión</p>
          </div>
        </div>
        <div className="header-right">
          <div className="user-info">
            <div className="user-avatar">
              {user?.username?.charAt(0).toUpperCase()}
            </div>
            <span>{user?.username}</span>
          </div>
          <button className="logout-button" onClick={logout}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Salir
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="dashboard-main">
        {/* Sidebar - User List */}
        <aside className="users-sidebar">
          <div className="sidebar-header">
            <h2>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>
              Usuarios Pendientes
            </h2>
            <button className="refresh-button" onClick={fetchPendingUsers} disabled={loading}>
              <svg className={loading ? 'animate-spin' : ''} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>
                <path d="M3 3v5h5"/>
                <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/>
                <path d="M21 21v-5h-5"/>
              </svg>
            </button>
          </div>

          {loading ? (
            <div className="sidebar-loading">
              <div className="loader"></div>
              <p>Cargando usuarios...</p>
            </div>
          ) : error ? (
            <div className="sidebar-error">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              <p>{error}</p>
              <button onClick={fetchPendingUsers}>Reintentar</button>
            </div>
          ) : (
            <UserList 
              users={users} 
              selectedUser={selectedUser}
              onSelectUser={handleSelectUser}
            />
          )}
        </aside>

        {/* Document Viewer */}
        <section className="viewer-section">
          <AnimatePresence mode="wait">
            {selectedUser ? (
              <DocumentViewer 
                key={selectedUser.userId}
                user={selectedUser}
                onValidate={handleValidate}
                onReject={handleReject}
                onClose={() => setSelectedUser(null)}
              />
            ) : (
              <motion.div 
                className="viewer-placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="placeholder-content">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="16" y1="13" x2="8" y2="13"/>
                    <line x1="16" y1="17" x2="8" y2="17"/>
                    <line x1="10" y1="9" x2="8" y2="9"/>
                  </svg>
                  <h3>Selecciona un usuario</h3>
                  <p>Elige un usuario de la lista para ver sus documentos</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>
    </div>
  )
}

export default Dashboard

