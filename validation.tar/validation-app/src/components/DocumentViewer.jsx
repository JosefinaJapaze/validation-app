import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import './DocumentViewer.css'

function DocumentViewer({ user, onValidate, onReject, onClose }) {
  const [files, setFiles] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [selectedFile, setSelectedFile] = useState(null)
  const [validating, setValidating] = useState(false)
  const [rejecting, setRejecting] = useState(false)
  const [rejectReason, setRejectReason] = useState('')
  const [showRejectModal, setShowRejectModal] = useState(false)

  useEffect(() => {
    fetchUserFiles()
  }, [user.userId])

  const fetchUserFiles = async () => {
    setLoading(true)
    setError('')
    
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/users/${user.userId}/files`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })

      if (!response.ok) throw new Error('Error al cargar archivos')

      const data = await response.json()
      setFiles(data.files)
      
      // Seleccionar el primer archivo por defecto
      if (data.files.length > 0) {
        setSelectedFile(data.files[0])
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleValidate = async () => {
    setValidating(true)
    await onValidate(user.userId)
    setValidating(false)
  }

  const handleReject = async () => {
    setRejecting(true)
    await onReject(user.userId, rejectReason)
    setRejecting(false)
    setShowRejectModal(false)
  }

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
  }

  return (
    <motion.div 
      className="document-viewer"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
    >
      {/* Header */}
      <div className="viewer-header">
        <div className="viewer-header-info">
          <button className="back-button" onClick={onClose}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5"/>
              <path d="m12 19-7-7 7-7"/>
            </svg>
          </button>
          <div className="viewer-user-info">
            <div className="viewer-user-avatar">
              {user.name?.charAt(0).toUpperCase() || user.userId?.charAt(0).toUpperCase()}
            </div>
            <div>
              <h2>{user.name || user.userId}</h2>
              <p>{user.email || 'Sin email registrado'}</p>
            </div>
          </div>
        </div>
        <div className="viewer-header-actions">
          <button 
            className="action-button reject"
            onClick={() => setShowRejectModal(true)}
            disabled={validating}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <path d="m15 9-6 6"/>
              <path d="m9 9 6 6"/>
            </svg>
            Rechazar
          </button>
          <button 
            className="action-button validate"
            onClick={handleValidate}
            disabled={validating || rejecting}
          >
            {validating ? (
              <>
                <span className="spinner"></span>
                Validando...
              </>
            ) : (
              <>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 6 9 17l-5-5"/>
                </svg>
                Validar Usuario
              </>
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="viewer-content">
        {/* Files Sidebar */}
        <div className="files-sidebar">
          <h3>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
              <polyline points="14 2 14 8 20 8"/>
            </svg>
            Documentos ({files.length})
          </h3>

          {loading ? (
            <div className="files-loading">
              <div className="loader"></div>
              <p>Cargando archivos...</p>
            </div>
          ) : error ? (
            <div className="files-error">
              <p>{error}</p>
              <button onClick={fetchUserFiles}>Reintentar</button>
            </div>
          ) : files.length === 0 ? (
            <div className="files-empty">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                <path d="M12 9v6"/>
                <path d="M9 12h6"/>
              </svg>
              <p>No hay documentos</p>
            </div>
          ) : (
            <div className="files-list">
              {files.map((file, index) => (
                <motion.button
                  key={file.key}
                  className={`file-item ${selectedFile?.key === file.key ? 'selected' : ''}`}
                  onClick={() => setSelectedFile(file)}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <div className={`file-icon ${file.type}`}>
                    {file.type === 'image' ? (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                        <circle cx="8.5" cy="8.5" r="1.5"/>
                        <polyline points="21 15 16 10 5 21"/>
                      </svg>
                    ) : file.type === 'pdf' ? (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                        <polyline points="14 2 14 8 20 8"/>
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                      </svg>
                    )}
                  </div>
                  <div className="file-info">
                    <span className="file-name">{file.name}</span>
                    <span className="file-size">{formatFileSize(file.size)}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          )}
        </div>

        {/* Preview Area */}
        <div className="preview-area">
          <AnimatePresence mode="wait">
            {selectedFile ? (
              <motion.div
                key={selectedFile.key}
                className="preview-content"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {selectedFile.type === 'image' ? (
                  <div className="image-preview">
                    <img src={selectedFile.url} alt={selectedFile.name} />
                  </div>
                ) : selectedFile.type === 'pdf' ? (
                  <div className="pdf-preview">
                    <iframe 
                      src={selectedFile.url} 
                      title={selectedFile.name}
                      frameBorder="0"
                    />
                  </div>
                ) : (
                  <div className="unsupported-preview">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                    </svg>
                    <p>Vista previa no disponible</p>
                    <a href={selectedFile.url} target="_blank" rel="noopener noreferrer" className="download-link">
                      Descargar archivo
                    </a>
                  </div>
                )}
                <div className="preview-footer">
                  <span>{selectedFile.name}</span>
                  <a href={selectedFile.url} target="_blank" rel="noopener noreferrer" className="open-button">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                      <polyline points="15 3 21 3 21 9"/>
                      <line x1="10" y1="14" x2="21" y2="3"/>
                    </svg>
                    Abrir en nueva pestaña
                  </a>
                </div>
              </motion.div>
            ) : (
              <div className="no-preview">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
                  <polyline points="14 2 14 8 20 8"/>
                </svg>
                <p>Selecciona un documento para ver</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Reject Modal */}
      <AnimatePresence>
        {showRejectModal && (
          <motion.div 
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowRejectModal(false)}
          >
            <motion.div 
              className="modal-content"
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="modal-header">
                <h3>Rechazar Usuario</h3>
                <button className="modal-close" onClick={() => setShowRejectModal(false)}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 6 6 18"/>
                    <path d="m6 6 12 12"/>
                  </svg>
                </button>
              </div>
              <div className="modal-body">
                <p>¿Estás seguro de rechazar a <strong>{user.name || user.userId}</strong>?</p>
                <label>
                  Motivo del rechazo (opcional):
                  <textarea 
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="Describe el motivo del rechazo..."
                    rows={3}
                  />
                </label>
              </div>
              <div className="modal-actions">
                <button 
                  className="modal-button cancel"
                  onClick={() => setShowRejectModal(false)}
                >
                  Cancelar
                </button>
                <button 
                  className="modal-button confirm"
                  onClick={handleReject}
                  disabled={rejecting}
                >
                  {rejecting ? 'Rechazando...' : 'Confirmar Rechazo'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export default DocumentViewer

