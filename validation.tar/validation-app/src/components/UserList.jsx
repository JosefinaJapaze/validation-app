import { motion } from 'framer-motion'
import './UserList.css'

function UserList({ users, selectedUser, onSelectUser }) {
  if (users.length === 0) {
    return (
      <div className="empty-list">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <circle cx="12" cy="12" r="10"/>
          <path d="M9 12l2 2 4-4"/>
        </svg>
        <h3>¡Todo validado!</h3>
        <p>No hay usuarios pendientes de revisión</p>
      </div>
    )
  }

  return (
    <div className="user-list">
      {users.map((user, index) => (
        <motion.button
          key={user.userId}
          className={`user-card ${selectedUser?.userId === user.userId ? 'selected' : ''}`}
          onClick={() => onSelectUser(user)}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <div className="user-card-avatar">
            {user.name?.charAt(0).toUpperCase() || user.userId?.charAt(0).toUpperCase() || '?'}
          </div>
          <div className="user-card-info">
            <h4>{user.name || user.userId}</h4>
            <p>{user.email || 'Sin email'}</p>
            <div className="user-card-meta">
              <span className="status-badge pending">
                <span className="status-dot"></span>
                Pendiente
              </span>
              {user.createdAt && (
                <span className="date">
                  {new Date(user.createdAt).toLocaleDateString('es-ES', {
                    day: 'numeric',
                    month: 'short'
                  })}
                </span>
              )}
            </div>
          </div>
          <div className="user-card-arrow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </div>
        </motion.button>
      ))}
    </div>
  )
}

export default UserList

