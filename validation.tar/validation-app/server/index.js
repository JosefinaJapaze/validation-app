import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

// Credenciales hardcodeadas para login
const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'admin123'
};

// ============================================
// DATOS HARDCODEADOS PARA PRUEBAS
// ============================================

// Usuarios de prueba
let mockUsers = [
  {
    userId: 'user-001',
    name: 'María García López',
    email: 'maria.garcia@email.com',
    status: 'pending',
    createdAt: '2024-12-05T10:30:00Z'
  },
  {
    userId: 'user-002',
    name: 'Carlos Rodríguez Pérez',
    email: 'carlos.rodriguez@email.com',
    status: 'pending',
    createdAt: '2024-12-06T14:15:00Z'
  },
  {
    userId: 'user-003',
    name: 'Ana Martínez Silva',
    email: 'ana.martinez@email.com',
    status: 'pending',
    createdAt: '2024-12-07T09:45:00Z'
  }
];

// Archivos de prueba por usuario (usando imágenes públicas de ejemplo)
const mockFiles = {
  'user-001': [
    {
      key: 'user-001/dni-frente.jpg',
      name: 'dni-frente.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1633265486064-086b219458ec?w=800&q=80',
      size: 245000,
      lastModified: '2024-12-05T10:35:00Z'
    },
    {
      key: 'user-001/dni-dorso.jpg',
      name: 'dni-dorso.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=800&q=80',
      size: 198000,
      lastModified: '2024-12-05T10:36:00Z'
    },
    {
      key: 'user-001/selfie.jpg',
      name: 'selfie.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&q=80',
      size: 312000,
      lastModified: '2024-12-05T10:37:00Z'
    },
    {
      key: 'user-001/comprobante-domicilio.pdf',
      name: 'comprobante-domicilio.pdf',
      type: 'pdf',
      url: 'https://www.w3.org/WAI/WCAG21/Techniques/pdf/img/table-word.pdf',
      size: 524000,
      lastModified: '2024-12-05T10:38:00Z'
    }
  ],
  'user-002': [
    {
      key: 'user-002/pasaporte.jpg',
      name: 'pasaporte.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1544725121-be3bf52e2dc8?w=800&q=80',
      size: 287000,
      lastModified: '2024-12-06T14:20:00Z'
    },
    {
      key: 'user-002/foto-perfil.jpg',
      name: 'foto-perfil.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
      size: 156000,
      lastModified: '2024-12-06T14:21:00Z'
    },
    {
      key: 'user-002/contrato.pdf',
      name: 'contrato.pdf',
      type: 'pdf',
      url: 'https://www.w3.org/WAI/WCAG21/Techniques/pdf/img/table-word.pdf',
      size: 892000,
      lastModified: '2024-12-06T14:22:00Z'
    }
  ],
  'user-003': [
    {
      key: 'user-003/cedula.jpg',
      name: 'cedula.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=800&q=80',
      size: 234000,
      lastModified: '2024-12-07T09:50:00Z'
    },
    {
      key: 'user-003/selfie-verificacion.jpg',
      name: 'selfie-verificacion.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=800&q=80',
      size: 278000,
      lastModified: '2024-12-07T09:51:00Z'
    },
    {
      key: 'user-003/recibo-luz.jpg',
      name: 'recibo-luz.jpg',
      type: 'image',
      url: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80',
      size: 189000,
      lastModified: '2024-12-07T09:52:00Z'
    },
    {
      key: 'user-003/declaracion.pdf',
      name: 'declaracion.pdf',
      type: 'pdf',
      url: 'https://www.w3.org/WAI/WCAG21/Techniques/pdf/img/table-word.pdf',
      size: 156000,
      lastModified: '2024-12-07T09:53:00Z'
    }
  ]
};

// ============================================
// ENDPOINTS
// ============================================

// Login endpoint
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  
  if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
    res.json({ 
      success: true, 
      token: 'hardcoded-token-12345',
      user: { username: 'admin', role: 'validator' }
    });
  } else {
    res.status(401).json({ success: false, message: 'Credenciales inválidas' });
  }
});

// Middleware simple de autenticación
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token === 'hardcoded-token-12345') {
    next();
  } else {
    res.status(401).json({ message: 'No autorizado' });
  }
};

// Obtener usuarios pendientes (HARDCODEADO)
app.get('/api/users/pending', authMiddleware, async (req, res) => {
  // Simular delay de red
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const pendingUsers = mockUsers.filter(u => u.status === 'pending');
  res.json({ users: pendingUsers });
});

// Obtener archivos de un usuario (HARDCODEADO)
app.get('/api/users/:userId/files', authMiddleware, async (req, res) => {
  const { userId } = req.params;
  
  // Simular delay de red
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const files = mockFiles[userId] || [];
  res.json({ files });
});

// Validar usuario (cambiar status a "valid")
app.post('/api/users/:userId/validate', authMiddleware, async (req, res) => {
  const { userId } = req.params;

  // Simular delay de red
  await new Promise(resolve => setTimeout(resolve, 800));

  const userIndex = mockUsers.findIndex(u => u.userId === userId);
  if (userIndex !== -1) {
    mockUsers[userIndex].status = 'valid';
    mockUsers[userIndex].validatedAt = new Date().toISOString();
    res.json({ success: true, user: mockUsers[userIndex] });
  } else {
    res.status(404).json({ message: 'Usuario no encontrado' });
  }
});

// Rechazar usuario (cambiar status a "rejected")
app.post('/api/users/:userId/reject', authMiddleware, async (req, res) => {
  const { userId } = req.params;
  const { reason } = req.body;

  // Simular delay de red
  await new Promise(resolve => setTimeout(resolve, 800));

  const userIndex = mockUsers.findIndex(u => u.userId === userId);
  if (userIndex !== -1) {
    mockUsers[userIndex].status = 'rejected';
    mockUsers[userIndex].rejectedAt = new Date().toISOString();
    mockUsers[userIndex].rejectionReason = reason || 'Sin especificar';
    res.json({ success: true, user: mockUsers[userIndex] });
  } else {
    res.status(404).json({ message: 'Usuario no encontrado' });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📋 Modo: DATOS DE PRUEBA HARDCODEADOS`);
  console.log(`👤 Usuarios de prueba: ${mockUsers.length}`);
  console.log(`🔐 Login: admin / admin123`);
});
