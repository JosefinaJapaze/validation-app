# Sistema de Validación de Usuarios

Aplicación para validar usuarios pendientes, visualizar sus documentos almacenados en S3 y cambiar su estado en DynamoDB.

## Características

- **Login hardcodeado** - Acceso con credenciales: `admin` / `admin123`
- **Lista de usuarios pendientes** - Consulta usuarios con status "pending" en DynamoDB
- **Visor de documentos** - Visualiza imágenes y PDFs almacenados en S3
- **Validación/Rechazo** - Cambia el estado del usuario a "valid" o "rejected"

## Requisitos

- Node.js 18+
- Cuenta AWS con acceso a DynamoDB y S3
- Credenciales AWS configuradas (via variables de entorno o `~/.aws/credentials`)

## Configuración AWS

### DynamoDB

Necesitas una tabla con la siguiente estructura:

```
Tabla: users (o el nombre que configures en DYNAMO_TABLE)
Partition Key: userId (String)

Atributos esperados:
- userId: String (ID único del usuario)
- status: String ("pending", "valid", "rejected")
- name: String (opcional)
- email: String (opcional)
- createdAt: String (ISO date, opcional)
```

### S3

Bucket con estructura de carpetas por usuario:

```
bucket-name/
├── user-id-1/
│   ├── documento1.pdf
│   ├── foto-dni.jpg
│   └── selfie.png
├── user-id-2/
│   ├── cedula.pdf
│   └── comprobante.jpg
```

## Variables de Entorno

Crea un archivo `.env` o configura estas variables:

```bash
# AWS
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=tu_access_key
AWS_SECRET_ACCESS_KEY=tu_secret_key

# App
DYNAMO_TABLE=users
S3_BUCKET=user-documents
PORT=3001
```

## Instalación

```bash
# Instalar dependencias
npm install

# Iniciar servidor backend
npm run dev:server

# En otra terminal, iniciar frontend
npm run dev

# O ambos a la vez
npm run dev:all
```

## Uso

1. Abre `http://localhost:5173`
2. Ingresa con `admin` / `admin123`
3. Verás la lista de usuarios pendientes
4. Selecciona un usuario para ver sus documentos
5. Revisa cada documento (imágenes y PDFs)
6. Haz clic en "Validar Usuario" o "Rechazar"

## API Endpoints

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/login` | Login con credenciales |
| GET | `/api/users/pending` | Obtener usuarios pendientes |
| GET | `/api/users/:userId/files` | Obtener archivos de un usuario |
| POST | `/api/users/:userId/validate` | Validar usuario (status → valid) |
| POST | `/api/users/:userId/reject` | Rechazar usuario (status → rejected) |

## Estructura del Proyecto

```
validation-app/
├── server/
│   └── index.js          # Backend Express + AWS SDK
├── src/
│   ├── components/
│   │   ├── Login.jsx     # Pantalla de login
│   │   ├── Dashboard.jsx # Panel principal
│   │   ├── UserList.jsx  # Lista de usuarios
│   │   └── DocumentViewer.jsx # Visor de documentos
│   ├── styles/
│   │   └── *.css         # Estilos
│   ├── App.jsx           # Componente principal
│   └── main.jsx          # Entry point
├── index.html
├── package.json
└── vite.config.js
```

## Cambiar Credenciales de Login

Edita `server/index.js`:

```javascript
const ADMIN_CREDENTIALS = {
  username: 'tu_usuario',
  password: 'tu_contraseña'
};
```

## Tecnologías

- **Frontend**: React + Vite + Framer Motion
- **Backend**: Express.js
- **AWS**: DynamoDB, S3 (con URLs presignadas)

